// Handles image selection, preview, upload, and result rendering
const palmInput = document.getElementById('palmInput');
const uploadArea = document.getElementById('uploadArea');
const selectBtn = document.getElementById('selectBtn');
const analyzeBtn = document.getElementById('analyzeBtn');
const preview = document.getElementById('preview');
const resultBox = document.getElementById('result');

let selectedFile = null;

uploadArea.addEventListener('click', () => palmInput.click());
selectBtn.addEventListener('click', () => palmInput.click());

palmInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;
  if (!file.type.startsWith('image/')) {
    alert('Please select an image file.');
    return;
  }
  if (file.size > 5 * 1024 * 1024) {
    alert('File too large. Max 5MB.');
    return;
  }
  selectedFile = file;
  analyzeBtn.disabled = false;
  const img = document.createElement('img');
  img.src = URL.createObjectURL(file);
  img.onload = () => URL.revokeObjectURL(img.src);
  preview.innerHTML = '';
  preview.appendChild(img);
  uploadArea.querySelector('.upload-text').innerText = "Image ready — click Analyze";
});

analyzeBtn.addEventListener('click', async () => {
  if (!selectedFile) {
    alert('Please select an image first.');
    return;
  }

  resultBox.innerHTML = '<p>🔮 Analyzing your palm — this may take a few seconds...</p>';

  const form = new FormData();
  form.append('image', selectedFile);

  try {
    const resp = await fetch('/api/palm-read', { method: 'POST', body: form });
    if (!resp.ok) {
      const err = await resp.json().catch(()=>({error:'unknown'}));
      resultBox.innerHTML = `<p>❌ Error: ${err.error || resp.statusText}</p>`;
      return;
    }
    const data = await resp.json();
    // data.formatSections is expected to be an array of {title, text}
    if (data.formatSections && Array.isArray(data.formatSections)) {
      resultBox.innerHTML = '<h3 class="section-title">Your Palm Reading</h3>';
      data.formatSections.forEach(sec => {
        const div = document.createElement('div');
        div.className = 'result-line';
        div.innerHTML = `<strong>${sec.title}</strong><div>${sec.text.replace(/\n/g,'<br>')}</div>`;
        resultBox.appendChild(div);
      });
    } else if (data.result) {
      resultBox.innerHTML = `<h3 class="section-title">Your Palm Reading</h3><div class="result-line">${data.result}</div>`;
    } else {
      resultBox.innerHTML = '<p>✅ Done — but no readable result returned.</p>';
    }
  } catch (err) {
    console.error(err);
    resultBox.innerHTML = '<p>❌ Unexpected error. Check console for details.</p>';
  }
});
