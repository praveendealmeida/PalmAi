// Vercel serverless function (Node.js) to receive an uploaded image and call OpenAI.
// NOTE: This implementation attempts a two-step approach:
// 1) Send the image (as base64) to the Responses API to get a vision-based analysis (if available).
// 2) Send that analysis text to your custom Assistant (Assistants API) to get a nicely formatted reading.
//
// Environment variables required in Vercel:
//
// OPENAI_API_KEY - your OpenAI API key
// ASSISTANT_ID - your custom GPT ID (e.g., g-68e63282...)
//
// IMPORTANT: The OpenAI platform evolves. If the Assistants API doesn't accept images directly in your org, the functions below
// first ask the Responses API to describe the palm image, then pass that description to your assistant to format and expand it.
//
// If you want a simpler single-call approach (and your assistant supports vision inputs directly), you can adapt the code to call the Assistants runs endpoint with an image input per OpenAI docs.

import { buffer } from 'micro';
import fs from 'fs';
import fetch from 'node-fetch';

export const config = {
  api: {
    bodyParser: false
  }
};

const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const ASSISTANT_ID = process.env.ASSISTANT_ID; // e.g., "g-68e63282c0bc8191a828439d3fd48877-sasthare"

if (!OPENAI_API_KEY) {
  console.warn('OPENAI_API_KEY is not set in environment variables.');
}
if (!ASSISTANT_ID) {
  console.warn('ASSISTANT_ID is not set in environment variables.');
}

function parseFormData(rawBody, boundary) {
  const parts = rawBody.split(boundary).filter(Boolean);
  const files = {};
  for (const part of parts) {
    if (part.indexOf('Content-Disposition') === -1) continue;
    const nameMatch = part.match(/name="([^"]+)"/);
    const filenameMatch = part.match(/filename="([^"]+)"/);
    const contentTypeMatch = part.match(/Content-Type: ([^\r\n]+)/);
    const start = part.indexOf('\r\n\r\n');
    const content = part.slice(start + 4, part.lastIndexOf('\r\n'));
    const fieldName = nameMatch && nameMatch[1];
    if (filenameMatch) {
      const filename = filenameMatch[1];
      const contentType = contentTypeMatch ? contentTypeMatch[1] : 'application/octet-stream';
      files[fieldName] = { filename, content, contentType };
    }
  }
  return files;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' });
    return;
  }

  try {
    // Read raw body and separate multipart form data manually (micro + formidable can be used too)
    const raw = (await buffer(req)).toString('binary');
    const contentType = req.headers['content-type'] || '';
    const boundaryMatch = contentType.match(/boundary=(?:"([^"]+)"|([^;]+))/i);
    if (!boundaryMatch) {
      return res.status(400).json({ error: 'No boundary found in content-type header' });
    }
    const boundary = '--' + (boundaryMatch[1] || boundaryMatch[2]);
    const files = parseFormData(raw, boundary);
    const imageField = files['image'];
    if (!imageField) {
      return res.status(400).json({ error: 'No image file uploaded' });
    }

    // Convert the binary content to base64. The 'content' we extracted is binary string; convert properly.
    // In Vercel's environment you might instead use a library like 'formidable' to parse. This is a lightweight fallback.
    const binaryStr = imageField.content;
    // Convert binary string to Buffer
    const buf = Buffer.from(binaryStr, 'binary');
    const b64 = buf.toString('base64');
    const dataUrl = `data:${imageField.contentType};base64,${b64}`;

    // Step 1: Ask the Responses API (vision-capable model) to describe the palm image.
    // This gives us a textual analysis the assistant can then expand & format.
    let visionAnalysis = null;

    try {
      const visionResp = await fetch('https://api.openai.com/v1/responses', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify({
          model: 'gpt-4o-mini', // model choice that may provide vision in your org
          input: [
            {
              role: 'user',
              content: `Examine the palm image provided. Describe the visible palm lines and notable features (Head line, Heart line, Life line, Fate line, mounts, major crosses, branchings, and any notable markings). Provide concise bullet points for each line.`
            },
            {
              role: 'user',
              content: dataUrl
            }
          ]
        })
      });
      const vjson = await visionResp.json();
      // Try to extract a useful text reply from Responses API output
      visionAnalysis = (vjson.output && vjson.output[0] && (vjson.output[0].content || vjson.output[0].text)) || JSON.stringify(vjson);
    } catch (e) {
      console.error('Vision API step failed:', e);
      // we'll continue — assistant may still accept text-only input
    }

    // Step 2: Send the visionAnalysis (or the raw note) to your Assistant to get a nicely formatted reading.
    // We will call the Assistants API runs endpoint. This endpoint shape can vary; the following is a common pattern.
    let assistantResult = null;
    try {
      const assistantPayload = {
        input: {
          // Give the assistant clear instructions and include the vision analysis (or say to analyze the image inline)
          content: `You are an expert palm reader. Format the reading into sections with these headings: 💓 Heart Line, 🧠 Head Line, 🔮 Fate Line, ❤️ Life Line, 🦵 Mounts & Other Markings. Use the following analysis (from a vision model) as the source. If the analysis is missing, ask to describe the image instead.\n\nVisionAnalysis:\n${visionAnalysis || 'No vision analysis available.'}\n\nReturn JSON with an array named "sections" where each item has "title" and "text".`
        }
      };

      const runsResp = await fetch(`https://api.openai.com/v1/assistants/${process.env.ASSISTANT_ID}/runs`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${OPENAI_API_KEY}`
        },
        body: JSON.stringify(assistantPayload)
      });

      const runsJson = await runsResp.json();
      // The exact assistant response shape varies; try to extract readable text
      assistantResult = runsJson.output && JSON.stringify(runsJson.output) || JSON.stringify(runsJson);
    } catch (e) {
      console.error('Assistant API step failed:', e);
    }

    // As a fallback, return the vision analysis if assistant formatting failed.
    if (assistantResult && assistantResult.length > 0) {
      // Try to parse JSON sections from assistantResult if it returns JSON text
      try {
        // If assistantResult is JSON string with sections, attempt parse
        const parsed = JSON.parse(assistantResult);
        if (parsed.sections) {
          return res.status(200).json({ formatSections: parsed.sections });
        }
      } catch (e) {
        // Not JSON — return raw assistant text
        return res.status(200).json({ result: assistantResult });
      }
    }

    // Final fallback: return visionAnalysis
    return res.status(200).json({ result: visionAnalysis || 'No analysis available' });

  } catch (err) {
    console.error('Unexpected error in /api/palm-read:', err);
    res.status(500).json({ error: 'Server error processing image' });
  }
}
